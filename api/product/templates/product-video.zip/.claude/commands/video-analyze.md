---
description: 分析產品
---

分析產品

依專案 `AGENTS.md` 的規則，執行 `schemas/workflow.json` 中 `steps` 的 `analyze`：先確認 `requires`，再依序完成 `actions`；有 `checkpoint` 時停下等待使用者確認。

做法見 product-video Skill 的 `workflow.md#analyze`；未安裝 Skill 時讀取 https://aoa.tigernaxo.com/api/product/skills/product-video/workflow.md#analyze
