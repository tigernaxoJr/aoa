---
description: 美術與角色
---

美術與角色

依專案 `AGENTS.md` 的規則，執行 `schemas/workflow.json` 中 `steps` 的 `design`：先確認 `requires`，再依序完成 `actions`；有 `checkpoint` 時停下等待使用者確認。

做法見 story-video Skill 的 `design-guide.md`；未安裝 Skill 時讀取 https://aoa.tigernaxo.com/api/story/skills/story-video/design-guide.md
