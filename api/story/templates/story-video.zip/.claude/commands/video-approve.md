---
description: 核准 scene
argument-hint: <id>
---

核准 scene：$ARGUMENTS

依專案 `AGENTS.md` 的規則，執行 `schemas/workflow.json` 中 `operations` 的 `approve`：先確認 `requires`，再依序完成 `actions`；有 `checkpoint` 時停下等待使用者確認。

參數：
- `id`（必填）
