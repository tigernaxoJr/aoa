---
description: 翻譯為其他語言
argument-hint: <locale>
---

翻譯為其他語言：$ARGUMENTS

依專案 `AGENTS.md` 的規則，執行 `schemas/workflow.json` 中 `operations` 的 `translate`：先確認 `requires`，再依序完成 `actions`；有 `checkpoint` 時停下等待使用者確認。

參數：
- `locale`（必填）：BCP 47 語言標籤，例如 en-US。

做法見 product-video Skill 的 `workflow.md#translate`；未安裝 Skill 時讀取 https://aoa.tigernaxo.com/api/product/skills/product-video/workflow.md#translate
