---
description: 撰寫簡報文案
---

撰寫簡報文案

依專案 `AGENTS.md` 的規則，執行 `schemas/workflow.json` 中 `steps` 的 `draft`：編寫 slides.md 各頁內文、標題、講者備忘錄，選配 Slidev 原生 layout 版型。
先用 `pnpm run state activity` 回報進度；有 `checkpoint` 時停下等待使用者確認，完成後以 `pnpm run state project --status` 更新狀態。

做法見 slidev-deck Skill 的 `SKILL.md#draft`；未安裝 Skill 時讀取 https://aoa.tigernaxo.com/api/slide/skills/slidev-deck/SKILL.md#draft
