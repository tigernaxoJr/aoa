---
description: 大綱與分頁規劃
---

大綱與分頁規劃

依專案 `AGENTS.md` 的規則，執行 `schemas/workflow.json` 中 `steps` 的 `outline`：依使用者提供的內容（slide.start.json 的 content、references/ 的參考資料或對話中的說明）與受眾，規劃簡報結構、頁數、每頁核心資訊與視覺形式；不知道要講什麼就先問使用者，不沿用範本示範頁的主題。
先用 `pnpm run state activity` 回報進度；有 `checkpoint` 時停下等待使用者確認，完成後以 `pnpm run state project --status` 更新狀態。

做法見 slidev-deck Skill 的 `SKILL.md#outline`；未安裝 Skill 時讀取 https://aoa.tigernaxo.com/api/slide/skills/slidev-deck/SKILL.md#outline
