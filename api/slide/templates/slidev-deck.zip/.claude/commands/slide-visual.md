---
description: 視覺圖表與 3D 注入
---

視覺圖表與 3D 注入

依專案 `AGENTS.md` 的規則，執行 `schemas/workflow.json` 中 `steps` 的 `visual`：在簡報中繪製 SVG 向量架構圖、流程圖、Iconify 圖示，並適度嵌入 Three.js / WebGL 3D 組件。
先用 `pnpm run state activity` 回報進度；有 `checkpoint` 時停下等待使用者確認，完成後以 `pnpm run state project --status` 更新狀態。

做法見 slidev-deck Skill 的 `visual-guide.md`；未安裝 Skill 時讀取 https://aoa.tigernaxo.com/api/slide/skills/slidev-deck/visual-guide.md
