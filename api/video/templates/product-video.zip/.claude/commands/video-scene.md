---
description: 產生單一 scene
argument-hint: <id>
---

產生單一 scene：$ARGUMENTS

依專案 `AGENTS.md` 的規則，執行 `schemas/workflow.json` 中 `steps` 的 `build_scene`：先確認 `requires`，再依序完成 `actions`；有 `checkpoint` 時停下等待使用者確認。

參數：
- `id`（必填）：scene id，或 all 表示依序處理所有需要處理的 scene。

做法見 product-video Skill 的 `rendering-guide.md`；未安裝 Skill 時讀取 https://aoa.tigernaxo.com/api/video/skills/product-video/rendering-guide.md
