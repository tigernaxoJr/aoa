---
description: 整理故事
---

整理故事

依專案 `AGENTS.md` 的規則，執行 `schemas/workflow.json` 中 `steps` 的 `develop_story`：先確認 `requires`，再依序完成 `actions`；有 `checkpoint` 時停下等待使用者確認。

做法見 story-video Skill 的 `story-guide.md#develop`；未安裝 Skill 時讀取 https://aoa.tigernaxo.com/api/undefined/skills/story-video/story-guide.md#develop
